import java.io.*;



public class IOHelper {
	File f;
	
	public static void main(String[] args){
		String temp="下载";
		String a = "星期四；三，四节；仙2 407；计算与软件工程";
		
		String b = a.substring(16);
		
		System.out.println("String b:"+b);
		try{
			File file=new File("test.txt");
			BufferedReader br=new BufferedReader(new FileReader(file));    
			BufferedWriter bw=new BufferedWriter(new FileWriter(file,true));
			
			String order=null;
			boolean value=false;
			while((order=br.readLine())!=null){
				if(temp.equals(order)){
					value=true; 
				}
				else{
					bw.write(order);
					bw.newLine();
				}
			}
			br.close();
			bw.flush();
			bw.close();
			
			if(value)System.out.println("已从文件中删除");	
			else System.out.println("未找到课程");
		}
		catch(Exception e){}
		
		try{
			System.out.println("请输入：");
			BufferedReader br1=new BufferedReader(new InputStreamReader(System.in,"UTF-8"));
			temp=br1.readLine();
			
			
			
			System.out.println("input:"+temp);
			
			if(temp.equals("下载")) System.out.println("corret");
			else System.out.println("wrong");
			
			
			FileWriter writer = new FileWriter("test.txt");
			String input = "下载2";
			writer.write(input);
			System.out.println(input);
			
			
			String s = System.getProperty("file.encoding");
			System.out.println(s);
			writer.close();
			
			File myFile = new File("test.txt");
			FileReader  fileReader = new FileReader(myFile);
			
			BufferedReader  reader = new BufferedReader(fileReader);
			String line = null;
			
			while((line = reader.readLine())!=null){
				System.out.println(line);
			}
			reader.close();
			
		}catch(IOException ex){
			ex.printStackTrace();
		}
	}

}
